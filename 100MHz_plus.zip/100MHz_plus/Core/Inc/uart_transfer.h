#ifndef UART_TRANSFER_H
#define UART_TRANSFER_H

#include "stm32h7xx_hal.h"  // Update as needed

void UART_Send_ADC_Data(void);

#endif // UART_TRANSFER_H
